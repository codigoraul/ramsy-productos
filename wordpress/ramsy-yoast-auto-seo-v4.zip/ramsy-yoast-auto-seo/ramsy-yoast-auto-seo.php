<?php
/**
 * Plugin Name: Ramsy — Yoast SEO Auto-fill para Productos
 * Plugin URI:  https://ramsy.cl
 * Description: Inyecta valores SEO en $_POST antes de que Yoast los lea, para que se guarden automáticamente.
 * Version:     1.4.0
 * Author:      Ramsy
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'RAMSY_SEO_SITE_NAME', 'RAMSY' );
define( 'RAMSY_SEO_SEP',       ' | ' );
define( 'RAMSY_SEO_SUFFIX',    'Instrumentación y Electrónica Industrial Chile' );
define( 'RAMSY_SEO_DESC_MAX',  155 );

/**
 * Prioridad 5 = corre ANTES que Yoast (que usa prioridad 10).
 * Inyectamos en $_POST los campos vacíos → Yoast los lee y los guarda como si el usuario los hubiera escrito.
 */
add_action( 'save_post', 'ramsy_inyectar_seo_en_post', 5, 2 );

function ramsy_inyectar_seo_en_post( $post_id, $post ) {

    // Solo productos
    if ( ! isset( $post->post_type ) || $post->post_type !== 'product' ) {
        return;
    }

    // Solo desde el formulario de admin (no API REST ni auto-save)
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( defined( 'REST_REQUEST' )  && REST_REQUEST )  return;
    if ( ! isset( $_POST['post_title'] ) )             return;
    if ( ! defined( 'WPSEO_VERSION' ) )                return;

    // ── Datos del POST (lo que el usuario acaba de guardar) ───────────────
    $nombre     = sanitize_text_field( $_POST['post_title'] ?? '' );
    $desc_corta = wp_strip_all_tags( $_POST['excerpt']  ?? '' );
    $desc_larga = wp_strip_all_tags( $_POST['content']  ?? '' );
    $texto_desc = $desc_corta ?: $desc_larga;

    // Categoría desde $_POST (tax_input viene como array de term IDs)
    $primera_cat = '';
    if ( ! empty( $_POST['tax_input']['product_cat'] ) ) {
        $term_ids = array_filter( (array) $_POST['tax_input']['product_cat'] );
        if ( ! empty( $term_ids ) ) {
            $term = get_term( reset( $term_ids ), 'product_cat' );
            if ( $term && ! is_wp_error( $term ) ) {
                $primera_cat = $term->name;
            }
        }
    }

    // Imagen del producto
    $imagen_url = '';
    $imagen_id  = get_post_thumbnail_id( $post_id );
    if ( $imagen_id ) {
        $imagen_url = wp_get_attachment_url( $imagen_id );
    }

    // ── Valores generados ─────────────────────────────────────────────────
    $titulo_seo = $primera_cat
        ? $nombre . RAMSY_SEO_SEP . $primera_cat . RAMSY_SEO_SEP . RAMSY_SEO_SITE_NAME
        : $nombre . RAMSY_SEO_SEP . RAMSY_SEO_SITE_NAME . ' — ' . RAMSY_SEO_SUFFIX;

    $meta_desc = '';
    if ( $texto_desc ) {
        $meta_desc = mb_strlen( $texto_desc ) <= RAMSY_SEO_DESC_MAX
            ? $texto_desc
            : mb_substr( $texto_desc, 0, mb_strrpos( mb_substr( $texto_desc, 0, RAMSY_SEO_DESC_MAX - 1 ), ' ' ) ) . '…';
    }

    $keyphrase = strtolower( $primera_cat ? "$nombre $primera_cat" : $nombre );

    // ── Inyectar en $_POST solo si el campo está vacío ────────────────────
    // Yoast lee estos campos exactamente con estos nombres
    $inyecciones = [
        'yoast_wpseo_focuskw'               => $keyphrase,
        'yoast_wpseo_title'                 => $titulo_seo,
        'yoast_wpseo_metadesc'              => $meta_desc,
        'yoast_wpseo_opengraph-title'       => $titulo_seo,
        'yoast_wpseo_opengraph-description' => $meta_desc,
        'yoast_wpseo_twitter-title'         => $titulo_seo,
        'yoast_wpseo_twitter-description'   => $meta_desc,
    ];

    if ( $imagen_url ) {
        $inyecciones['yoast_wpseo_opengraph-image'] = $imagen_url;
        $inyecciones['yoast_wpseo_twitter-image']   = $imagen_url;
    }

    foreach ( $inyecciones as $campo => $valor ) {
        if ( ! empty( $valor ) && empty( $_POST[ $campo ] ) ) {
            $_POST[ $campo ] = $valor;
        }
    }
}


// ── Exponer yoast_head en la API REST de WooCommerce ─────────────────────────

add_action( 'rest_api_init', function () {
    if ( ! function_exists( 'YoastSEO' ) ) return;

    register_rest_field( 'product', 'yoast_head', [
        'get_callback' => function ( $data ) {
            try {
                $surface = YoastSEO()->classes->get( \Yoast\WP\SEO\Surfaces\Meta_Surface::class );
                $meta    = $surface ? $surface->for_post( $data['id'] ) : null;
                return $meta ? $meta->get_head()->html : null;
            } catch ( \Exception $e ) { return null; }
        },
        'schema' => [ 'type' => 'string', 'context' => [ 'view' ], 'readonly' => true ],
    ] );

    register_rest_field( 'product', 'yoast_head_json', [
        'get_callback' => function ( $data ) {
            try {
                $surface = YoastSEO()->classes->get( \Yoast\WP\SEO\Surfaces\Meta_Surface::class );
                $meta    = $surface ? $surface->for_post( $data['id'] ) : null;
                return $meta ? ( $meta->get_head()->json ?? null ) : null;
            } catch ( \Exception $e ) { return null; }
        },
        'schema' => [ 'type' => 'object', 'context' => [ 'view' ], 'readonly' => true ],
    ] );
} );
